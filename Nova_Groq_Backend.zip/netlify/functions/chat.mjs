// Netlify Function: /.netlify/functions/chat
// Provider: Groq API (OpenAI-compatible Chat Completions endpoint)

export default async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed." }, { status: 405 });
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "GROQ_API_KEY is missing in Netlify environment variables." },
      { status: 500 }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON request." }, { status: 400 });
  }

  const message = typeof body?.message === "string" ? body.message.trim() : "";
  if (!message) {
    return Response.json({ error: "Message is empty." }, { status: 400 });
  }

  try {
    const groqResponse = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "openai/gpt-oss-120b",
          messages: [
            {
              role: "system",
              content:
                "You are Nova, a helpful, friendly AI assistant. Give clear, accurate, useful answers. Match the user's language. If unsure, say so rather than inventing facts.",
            },
            { role: "user", content: message },
          ],
          temperature: 0.7,
          max_completion_tokens: 2048,
        }),
      }
    );

    const result = await groqResponse.json().catch(() => ({}));

    if (!groqResponse.ok) {
      // Keep the provider's status so quota, key, and model errors can be diagnosed.
      const providerMessage =
        result?.error?.message || `Groq request failed (${groqResponse.status}).`;
      const status =
        groqResponse.status === 429 ? 429 :
        groqResponse.status === 401 || groqResponse.status === 403 ? 502 :
        groqResponse.status >= 500 ? 503 : 502;

      return Response.json(
        { error: providerMessage, providerStatus: groqResponse.status },
        { status }
      );
    }

    const reply = result?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return Response.json(
        { error: "Groq returned an empty response. Please try again." },
        { status: 502 }
      );
    }

    return Response.json({ reply: reply.trim() });
  } catch (error) {
    return Response.json(
      { error: "Could not reach Groq. Please try again shortly." },
      { status: 503 }
    );
  }
};
